﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Converters;
using System.Xml;
using System.IO;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            _Form1 = this;
        }


        public static Form1 _Form1;
        public void update(string message)
        {
            richTextBox1.AppendText("mess: " + message);
            //MessageBox.Show(message);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Class1 cs = new Class1();
                cs.testLog();

            }
            catch(Exception ex)
            {
                // addLog("Erro Metodo " + ex.Message);
                throw new Exception("Erro " + ex.Message);
            }



        //    if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {                             
        //        string xmlHeader = @"{'?xml': {'@version': '1.0','@encoding': 'UTF-8'},'return':";
      //          string sJson = xmlHeader + "{'idVeiculo':665249,'dataPosicao':'2016-06-21 00:00:34.0','dataPacote':'2016-06-21 00:00:34.0','latitude':-22.770326666666666,'longitude':-43.39966833333333,'direcao':0,'velocidade':0,'ignicao':0,'odometro':209150,'horimetro':216185,'tensao':22,'saida1':0,'saida2':-240,'saida3':-254,'saida4':0,'entrada1':0,'entrada2':-219,'entrada3':-251,'entrada4':0,'satelite':0,'memoria':0,'idReferencia':0,'bloqueio':0,'gps':1,'uf':'RJ','cidade':'Belford Roxo','rua':'Sem nome','pontoReferencia':'GPA - CD 1939 FRIGORIFICADOS - Belford Roxo_RJ','anguloReferencia':0,'distanciaReferencia':0,'rpm':0,'temperatura1':17,'temperatura2':-125,'temperatura3':-125,'saida5':0,'saida6':0,'saida7':0,'saida8':0,'entrada5':-247,'entrada6':-248,'entrada7':-231,'entrada8':0,'pontoEntrada':0,'pontoSaida':0,'codigoMacro':0,'nomeMensagem':'','conteudoMensagem':'','textoMensagem':'','tipoTeclado':0,'eventoSequenciamento':[],'eventos':[],'jamming':0,'idPacote':1682189733,'integradoraId':48}";
                                                                
    //            XmlDocument doc = (XmlDocument)JsonConvert.DeserializeXmlNode(sJson);
                
  //              string xml = doc.DocumentElement.InnerXml.ToString();// OuterXml.ToString();
                //TextWriter twriter = File.CreateText("C:/sascar/ps.xml");

//                doc.Save(twriter);
                

//                richTextBox1.Text = xml;

            }
        }
    }
}
